""" Message utilities

         
"""
from __future__ import annotations

import re

from ._colorize import colorize
from .. import (
        opts,
        decorators,
        )

RQUOTES = re.compile(r'''("|')''')

__all__  = [
        'Lines',
        'fmt_msg',
        'ask_yes',
        ]

def ask_yes(
        msg: str|None = None, 
        color: str = None,
        strict: bool = True,
        default_yes: bool = False,
        please: str | None = None,
        ):
    """ Asks for user confirmation and returns True if confirmed.
    Case insensitive.

    Parameters
    ----------
    msg: str
        Message to confirm
    """
    if default_yes is False:
        if please is None:
            please = f'Please type YES to continue or NO to exit: '
        try_again = "You must type YES or NO"
    else:
        if please is None:
            please = f"Press [ENTER] to continue, or type NO to exit: "
        try_again = "You must either press [ENTER] or type YES/NO"




    if msg is not None:
        msg = f"{msg}\n{please}"
    else:
        msg = please

    # Decide valid answers
    yes = {'yes'}
    no = {'no'}

    if strict is False:
        yes.add('y')
        no.add('n')

    valid = yes | no

    if color is not None:
        msg = colorize(msg, color=color)

    answer = input(msg)
    chk_answer = RQUOTES.sub('', answer.lower().strip())
    try_again = f"{try_again}, not '{answer}'. Try again: "

    if len(chk_answer) == 0: 
        if default_yes:
            return True
        else:
            return ask_yes(please=try_again, strict=strict,
                           default_yes=default_yes)
    elif chk_answer not in valid:
        return ask_yes(please=try_again, strict=strict,
                       default_yes=default_yes)
    elif chk_answer in yes:
        return True
    else:
        return False


class Lines(list):
    """ Message to be printed
    """

    def add(
            self, 
            line: str,
            sep: bool = False,
            strip: bool = False,
            newline: bool = False,
            bold: bool = False,
            color: str|None = None,
            indent: str = '',
            index: int|None = None,
            ):
        """  Adds a line line to the message

        Parameters
        ----------
        line : str
            The line to add
        sep : bool
            If True, insert separators
            Defaults to False
        strip : bool
            If True, strip the line first
            Defaults to False
        newline : bool
            If True, add a newline char after the (stripped) line
            Defaults to False
        bold : bool
            If True, line (and separators) will be printed in bold
            Defaults to False
        index : int, optional
            If None, append the element to the end of the list, 
            otherwise, insert 
            Defaults to None
        indent: str, default ''
            If given, add indentation to this line.
            If strip is True, indentation will be added after stripping

        Examples
        --------
        >>> import tk_utils
        >>> tk_utils.cfg.pp.min_sep_width = 5
        >>> msg = tk_utils.pp.Lines([0, 1, 4])
        >>> msg.add('a', sep=True, index=2)
        >>> print(msg)
        [0, 1, '-----', 'a', '-----', 4]

        """
        new = [line if strip is False else line.strip()]
        if sep is True:
            _sep = '-' * max(len(line), opts.cfg.pp.min_sep_width)
            new = [_sep] + new + [_sep]
        if newline is True:
            new.append('')
        if color is not None:
            new = [colorize(x, color) for x in new]
        if bold is True:
            #   [ANSI escape codes](https://en.wikipedia.org/wiki/ANSI_escape_code)
            new = [f"\033[1m{x}\033[0m" for x in new]

        if len(indent) > 0:
            new = [f"{indent}{x}" for x in new]

        if index is None:
            self.extend(new)
        else:
            for i, ele in enumerate(new):
                self.insert(index+i, ele)


    def print(self, quiet: bool = False):
        """ Prints the current message (list of strings)
        """
        if quiet is False:
            print('\n'.join(self))


def _msg_as_hdr(
        msg: str | list, 
        min_len: int = 40,
        max_len: int = 80, 
        sep: str = '-'):
    """ Returns a list with the message enclosed in separator lines
    """
    if isinstance(msg, str):
        msg = [msg]
    sep_len = min(max_len, max(min_len, max(len(x) for x in msg)))
    line = sep*sep_len
    return [line] + msg + [line]



def fmt_msg(
        msg, 
        color: str | None = None, 
        indent: str = '',
        as_hdr: bool = False,
        ):
    """ Returns a formatted message to print

    Parameters
    ----------
    msg : list, str
        Message to be formatted. If list, return a '\n'-joined string

    color : str, optional

    indent : str
        The string to prefix/indent every line in the message
        Defaults to ''

    as_hdr: bool, optional
        If True, enclose message in separator lines


    Examples
    --------
    >>> import tk_utils
    >>> msg = 'This is a msg'
    >>> print(tk_utils.pp.fmt_msg(msg, as_hdr=True))
    ----------------------------------------
    This is a msg
    ----------------------------------------

    """
    if indent is None:
        indent = ''
    if as_hdr is True:
        msg = _msg_as_hdr(msg)
    if isinstance(msg, (tuple, list)):
        msg = '\n'.join([f'{indent}{x}' for x in msg])
    else:
        msg = f'{indent}{msg}'
    if color is not None:
        return colorize(msg, color=color)
    else:
        return msg



