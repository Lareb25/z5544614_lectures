""" Pretty printer
"""
from __future__ import annotations

import io
import textwrap
import csv
import dataclasses as dc
import pprint as _pp

import pandas as pd

from .. import (
        opts,
        decorators,
        )
from . import (
        _msg,
        )

# TODO: Incomplete

PP_PARMS = {
    'pretty': '''
    pretty : bool, optional
        If True, use pprint.pformat as a print formatter. Otherwise, use str()
        Defaults to True
    ''',
    'indent': '''
    indent: str, optional 
        Indentation to be added.
        Defaults to '' (no indentation)
    ''',
    'show_type': '''
    show_type : bool, optional
        If True, pretty print will also display the object type.
        Defaults to True
    ''',
    'df_info': '''
    df_info : bool, optional
        If True and object is a pandas data frame, call the `info` method
        Defaults to False
    ''',
    'width': '''
    width : int, optional
        Parameter `width` to be passed to pretty printer. Ignored if `pretty`
        is False.
        Defaults to 40
    ''',
    'sort_dicts': '''
    sort_dicts : bool, optional
        Parameter `sort_dicts` to be passed to the pretty printer. 
        Defaults to False
    ''',
    'df_max_cols': '''
    df_max_cols: int, optional
        Number of data frame columns to display. 
        Defaults to None (all columns)
    ''',
    'df_max_rows': '''
    df_max_rows: int, optional
        Number of data frame rows to display
        Defaults to None (all columns)
    ''',
    'as_string': '''
    as_string : bool, optional
        If True, returns a string instead of writing to standard output.
        Defaults to True
    ''',
    'sep': '''
    sep: bool, optional
        If True, includes a message separator
        Defaults to False
    ''',
    }




def _get_df_info(df):
    """ Returns a string with the contents of df.info()

    Parameters
    ----------
    df : data frame

    Returns
    -------
    str
        A string with the output of `df.info()`

    """
    _stdout = io.StringIO()
    df.info(buf=_stdout)
    return _stdout.getvalue()


def _obj_as_str(obj, **kargs):
    """ Returns the string representation of an object
    """
    opts = pp_cfg._copy(**kargs)

    # String representing the object
    if isinstance(obj, (pd.DataFrame, pd.Series)):
        _kargs = {
            'max_rows': opts.df_max_rows,
            }
        if isinstance(obj, pd.DataFrame):
            _kargs['max_cols'] = opts.df_max_cols
        else:
            _kargs.update({
                'name': False if opts.as_string is True else True,
                'dtype': False if opts.as_string is True else True,
                })
        return obj.to_string(**_kargs)
    elif isinstance(obj, str):
        return obj
    else:
        if opts.pretty is True:
            return _pp.pformat(obj, **opts._pp_kargs())
        else:
            return str(obj)


@decorators.doc(indent=1, parms=PP_PARMS)
def pprint(obj: object,
           msg: str|None = None, 
           **kargs):
    """ Pretty prints `obj`. If object is a string, print it as is.

    NOTE: Will ignore str instances with value '?'

    Parameters
    ----------
    obj : any object 

    msg : str, optional
        Message preceding obj representation.
        Defaults to None.

    **kargs
        Overrides the default pretty print parameters (stored in
        lec_utils.pp_cfg):

    {pretty}
    {indent}
    {show_type}
    {df_info}
    {df_max_cols}
    {df_max_rows}
    {width}
    {sort_dicts}
    {as_string}
    {sep}


    Usage
    -----

    >> import tk_utils

    To create a DF from a CSV-formatted string (not file):

    >>  cnts = '''
        date       , ticker , Some rets
        2020-03-23 , aapl   , 0.0043158473975633
        2020-03-24 , aapl   , 0.0069854151404052
        '''
    >> df = tk_utils.csv_to_df(cnts)
    >> print(df)

                 date ticker  Some rets
        0  2020-03-23   aapl   0.004316
        1  2020-03-24   aapl   0.006985

    To pretty print an object use the `pprint` function. For instance, using the
    `df` created above:

    >> tk_utils.pprint(df, sep=True, show_type=True)

        ----------------------------------------
                 date ticker  Some rets
        0  2020-03-23   aapl   0.004316
        1  2020-03-24   aapl   0.006985

        Object type is <class 'pandas.core.frame.DataFrame'>
        ----------------------------------------


    Default parameters for the `pprint` function are stored in the `pp_cfg` object
    
    >> print(tk_utils.pp_cfg)
    
        _PPrintCfg({{'pretty': True,
         'indent': '',
         'show_type': True,
         'df_info': False,
         'df_max_cols': None,
         'df_max_rows': None,
         'width': 40,
         'sort_dicts': False,
         'as_string': False,
         'sep': False}})
    
    
    The default parameters can be modified. For instance, separator
    lines are not included in the output of `tk_utils.pprint` by default. To
    change this behavior set the parameter `sep` to True:
    
    >> tk_utils.pprint(df)         # sep = False by default
    
                 date ticker  Some rets
        0  2020-03-23   aapl   0.004316
        1  2020-03-24   aapl   0.006985
    
    
    >> tk_utils.pp_cfg.sep = True  # Change the default to True
    
    >> tk_utils.pprint(df)         # sep = False by default
    
        ----------------------------------------
                 date ticker  Some rets
        0  2020-03-23   aapl   0.004316
        1  2020-03-24   aapl   0.006985
        ----------------------------------------


        
    """

    # Ignore '?'
    if isinstance(obj, str) and obj == '?':
        return None

    # Initialize objects
    opts = pp_cfg._copy(**kargs)

    lines = _msg.Lines()
    _sep = '-'*opts.width

    if opts.sep is True:
        lines.add(_sep)

    # Add msg and str representation of the obj
    if msg is not None:
        if not msg.endswith('\n'):
            msg += '\n'
        lines.add(_obj_as_str(msg, **kargs))
    lines.add(_obj_as_str(obj, **kargs))

    # Add other info

    # df info
    if isinstance(obj, pd.DataFrame) and opts.df_info is True:
        lines.add('')
        s = _get_df_info(obj)
        lines.extend(s.splitlines())

    elif opts.show_type is True:
        lines.add('')
        lines.add(_obj_as_str(f"Object type is {type(obj)}", **kargs))

    if opts.sep is True:
        lines.add(_sep)

    # Final string
    output = '\n'.join(f"{opts.indent}{x}" for x in lines)

    if opts.as_string is True:
        return output
    else:
        print(output)

