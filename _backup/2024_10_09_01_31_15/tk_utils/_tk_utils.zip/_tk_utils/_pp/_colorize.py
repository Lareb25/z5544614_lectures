""" Colorize tools

Colorize

This module is imported by api.py


Notes
-----

ANSI sequences


ESC [ <param> ; <param> ... <command>

where 

- <param> is an integer 
- <command> is a single letter

References
----------

- colorama: https://github.com/tartley/colorama/tree/master

- ANSI escape codes: http://en.wikipedia.org/wiki/ANSI_escape_code

    | Name                | FG | BG  |
    |---------------------+----+-----|
    | Black               | 30 | 40  |
    | Red                 | 31 | 41  |
    | Green               | 32 | 42  |
    | Yellow              | 33 | 43  |
    | Blue                | 34 | 44  |
    | Magenta             | 35 | 45  |
    | Cyan                | 36 | 46  |
    | White               | 37 | 47  |
    | Bright Black (Gray) | 90 | 100 |
    | Bright Red          | 91 | 101 |
    | Bright Green        | 92 | 102 |
    | Bright Yellow       | 93 | 103 |
    | Bright Blue         | 94 | 104 |
    | Bright Magenta      | 95 | 105 |
    | Bright Cyan         | 96 | 106 |
    | Bright White        | 97 | 107 |

- termcolor: https://github.com/termcolor/termcolor/blob/main/src/termcolor/termcolor.py


"""
# TODO: Using classes is not ideal, better to create a factory of dictionaries
# mappping the name to the ANSI code
from __future__ import annotations

import pprint as _pp

__all__ = [
    'Colorizer',
    'colorize',
    ]


class AnsiCodes(dict):
    """ ANSI code dictionary with attribute access

    References
    ----------
    Src: https://stackoverflow.com/questions/1305532/convert-nested-python-dict-to-object
    """

    def __getattr__(self, name):
        if name in self:
            return self[name]
        else:
            raise AttributeError(f"No such attribute: {name}")

    def __setattr__(self, name, value):
        self[name] = value

    def __delattr__(self, name):
        if name in self:
            del self[name]
        else:
            raise AttributeError(f"No such attribute: {name}")

    def __str__(self):
        return _pp.pformat(self, width=40, sort_dicts=False)


# name: (fg, bg)
_BASE_COLOR_MAP = {
    'black':            (30, 40 ),
    'red':              (31, 41 ),
    'green':            (32, 42 ),
    'yellow':           (33, 43 ),
    'blue':             (34, 44 ),
    'magenta':          (35, 45 ),
    'cyan':             (36, 46 ),
    'white':            (37, 47 ),
    'light_black':      (90, 100),
    'light_red':        (91, 101),
    'light_green':      (92, 102),
    'light_yellow':     (93, 103),
    'light_blue':       (94, 104),
    'light_magenta':    (95, 105),
    'light_cyan':       (96, 106),
    'light_white':      (97, 107),
    }

_STYLE_MAP = {
    "bold": 1,
    "dark": 2,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "concealed": 8,
}

def _mk_code(code):
    return f"\033[{code}m"


def _align(rows, min_col_size: int = 10):
    """ Returns an aligned table with tups (x,y)
    """
    lsize, rsize = (min_col_size, min_col_size)
    for x, y in rows:
        lsize, rsize = (max(lsize, len(x)), max(rsize, len(y)))
    fmt = f"{{: <{lsize}}} {{: <{rsize}}}"
    return [fmt.format(*row) for row in rows]

def _chk_type(parm, value, typ):
    """
    """
    if not isinstance(value, typ):
        if isinstance(typ, (list, tuple)):
            valid = ','.join(f"'{x}'" for x in typ)
        else:
            valid = f"'{typ}'"
        raise TypeError(f"Parm `{parm}` must be {valid} not '{type(value)}'")

# ----------------------------------------------------------------------------
# Style and color dicts. Map the names to ANSI codes
# Note: color names refer to FG. BG colors start with a prefix 'bg_'
# ----------------------------------------------------------------------------
RESET = "\033[0m"
STYLES = {name: _mk_code(code) for name, code in _STYLE_MAP.items()}
COLORS = {name: _mk_code(tup[0]) for name, tup in _BASE_COLOR_MAP.items()} 
COLORS.update({f"bg_{name}": _mk_code(tup[1]) for name, tup in _BASE_COLOR_MAP.items()})

ANSI_CODES = AnsiCodes(STYLES | COLORS | {'reset': RESET})



class Colorizer:
    """

    Parameters
    ----------
    ansi_codes: dict
        A dictionary mapping names to ANSI codes
    """


    def __init__(
            self,
            ansi_codes: dict = ANSI_CODES,
            ):
        self.ansi_codes = ansi_codes


    def _chk_name(self, name):
        """ Asserts color/style name exists
        """
        if name not in self.ansi_codes:
            msg = f"Name '{name}' not mapped to an ANSI code"
            raise ValueError(msg)



    def show_colors(self):
        """ Prints a table with the color names in the color they represent
        """
        # Sort by color name
        #names = []
        #for name in self.ansi_codes:
        #    cname = name.split('_')[-1]
        #    names.append((cname, name))
        #rows = []
        #for _, name in sorted(names):
        #    code = self.ansi_codes[name]
        #    cname = self.colorize
        #    row = (name, self.colorize(name, color=name))
        #    rows.append(row)
        rows = [(x, self.colorize(x, color=x)) for x in sorted(self.ansi_codes)]
        rows = _align(rows)
        for row in rows:
            print(row)

    def _get_code(self, name):
        """ Returns the ANSI code of the color/style named `name`
        """
        self._chk_name(name)
        return self.ansi_codes[name]

    def colorize(
            self,
            text: str,
            color: str | None,
            style: str|list|None = None,
            bg: str|None = None,
            reset: bool = True,
            ):
        """
        """
        _chk_type('text', text, str)
        if color is not None:
            _chk_type('color', color, str)
            out = self._get_code(color) + text
        else:
            out = text

        if bg is not None:
            _chk_type('bg', bg, str)
            out = self._get_code(bg) + out

        if style is not None:
            styles = [style] if isinstance(style, str) else style
            for s in styles:
                out = self._get_code(s) + out

        if reset:
            out = out + self._get_code('reset')
        return out


colorizer = Colorizer(ansi_codes=ANSI_CODES)


# TODO: Finish docstring
def colorize(
        text: str,
        color: str | None,
        style: str|list|None = None,
        bg: str|None = None,
        reset: bool = True,
        ):
    """ Colorize a string 

    Parameters
    ----------
    text: str
        Text to colorize
    color: str
        Color. Valid values are
            'black',            
            'red',              
            'green',            
            'yellow',           
            'blue',             
            'magenta',          
            'cyan',             
            'white',            
            'light_black',      
            'light_red',        
            'light_green',      
            'light_yellow',     
            'light_blue',       
            'light_magenta',    
            'light_cyan',       
            'light_white',      

    Examples
    --------

    >>> import tk_utils
    >>> tk_utils.pp.colorize('some text', color=None, reset=False)
    'some text'

    >>> tk_utils.pp.colorize('some text', color='yellow', reset=True)
    '\\x1b[33msome text\\x1b[0m'

    """
    if color == 'bold' and style is None:
        color = None
        style = 'bold'

    return colorizer.colorize(
            text=text,
            color=color,
            style=style,
            bg=bg,
            reset=reset,
            )























