""" Types

"""
from __future__ import annotations

from os import PathLike
from collections import namedtuple
from types import (
        NoneType,
        )
from collections.abc import (
        Collection,
        Hashable,
        Iterable,
        Iterator,
        Mapping,
        MutableMapping,
        MutableSequence,
        Sequence,
        Set,
        )
from typing import (
        Any,
        Callable,
        ClassVar,
        Literal,
        Optional,
        Protocol,
        TYPE_CHECKING,
        TextIO,
        Type as type_t,
        TypeVar,
        Union,
        )

# used in decorators to preserve the signature of the function it decorates
# see https://mypy.readthedocs.io/en/stable/generics.html#declaring-decorators
FuncType = Callable[..., Any]
ClassType = type[...]













